import { app } from "./app.js"

let r = app()
console.log(r)